package com.example.portfolioapp

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ProjectListActivity : AppCompatActivity() {
    private val list = mutableListOf<Project>()
    private lateinit var adapter: ProjectAdapter
    private lateinit var tvEmpty: TextView

    private val projectsRef by lazy {
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        FirebaseFirestore.getInstance().collection("users").document(uid).collection("projects")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project_list)

        tvEmpty = findViewById(R.id.tvEmpty)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        adapter = ProjectAdapter(list) { project -> deleteProject(project) }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        loadProjects()
    }

    private fun loadProjects() {
        projectsRef.get().addOnSuccessListener { snapshot ->
            list.clear()
            for (doc in snapshot.documents) {
                val p = doc.toObject(Project::class.java)
                if (p != null) {
                    p.id = doc.id
                    list.add(p)
                }
            }
            adapter.notifyDataSetChanged()
            tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun deleteProject(p: Project) {
        projectsRef.document(p.id).delete().addOnSuccessListener { loadProjects() }
    }
}