package com.example.portfolioapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AddProjectActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_project)

        val etTitle = findViewById<EditText>(R.id.etTitle)
        val etDescription = findViewById<EditText>(R.id.etDescription)
        val etTech = findViewById<EditText>(R.id.etTech)
        val etLink = findViewById<EditText>(R.id.etLink)

        findViewById<Button>(R.id.btnSaveProject).setOnClickListener {
            if (etTitle.text.toString().trim().isEmpty()) {
                etTitle.error = "Project title is required"
                return@setOnClickListener
            }

            val project = hashMapOf(
                "title" to etTitle.text.toString().trim(),
                "description" to etDescription.text.toString().trim(),
                "techStack" to etTech.text.toString().trim(),
                "link" to etLink.text.toString().trim()
            )

            val uid = FirebaseAuth.getInstance().currentUser!!.uid
            FirebaseFirestore.getInstance().collection("users").document(uid)
                .collection("projects").add(project)
                .addOnSuccessListener {
                    Toast.makeText(this, "Project added", Toast.LENGTH_SHORT).show()
                    finish()
                }
                .addOnFailureListener {
                    Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                }
        }
    }
}