package com.example.portfolioapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class ProfileActivity : AppCompatActivity() {
    private lateinit var etName: EditText
    private lateinit var etCollege: EditText
    private lateinit var etBranch: EditText
    private lateinit var etCgpa: EditText
    private lateinit var etBio: EditText
    private lateinit var etSkills: EditText
    private lateinit var etGithub: EditText
    private lateinit var etLinkedin: EditText

    private val db = FirebaseFirestore.getInstance()
    private val user = FirebaseAuth.getInstance().currentUser!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        etName = findViewById(R.id.etName)
        etCollege = findViewById(R.id.etCollege)
        etBranch = findViewById(R.id.etBranch)
        etCgpa = findViewById(R.id.etCgpa)
        etBio = findViewById(R.id.etBio)
        etSkills = findViewById(R.id.etSkills)
        etGithub = findViewById(R.id.etGithub)
        etLinkedin = findViewById(R.id.etLinkedin)

        // Load existing data so the student can edit it
        db.collection("users").document(user.uid).get().addOnSuccessListener { d ->
            if (d.exists()) {
                etName.setText(d.getString("name"))
                etCollege.setText(d.getString("college"))
                etBranch.setText(d.getString("branch"))
                etCgpa.setText(d.getString("cgpa"))
                etBio.setText(d.getString("bio"))
                etSkills.setText(d.getString("skills"))
                etGithub.setText(d.getString("github"))
                etLinkedin.setText(d.getString("linkedin"))
            }
        }

        findViewById<Button>(R.id.btnSaveProfile).setOnClickListener { saveProfile() }
    }

    private fun saveProfile() {
        val data = hashMapOf(
            "name" to etName.text.toString().trim(),
            "college" to etCollege.text.toString().trim(),
            "branch" to etBranch.text.toString().trim(),
            "cgpa" to etCgpa.text.toString().trim(),
            "bio" to etBio.text.toString().trim(),
            "skills" to etSkills.text.toString().trim(),
            "github" to etGithub.text.toString().trim(),
            "linkedin" to etLinkedin.text.toString().trim(),
            "email" to (user.email ?: "")
        )

        db.collection("users").document(user.uid).set(data, SetOptions.merge())
            .addOnSuccessListener {
                Toast.makeText(this, "Profile saved", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
            }
    }
}