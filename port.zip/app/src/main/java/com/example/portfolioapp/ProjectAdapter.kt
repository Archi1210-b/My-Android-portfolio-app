package com.example.portfolioapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProjectAdapter(
    private val list: List<Project>,
    private val onDelete: (Project) -> Unit
) : RecyclerView.Adapter<ProjectAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.tvTitle)
        val tech: TextView = v.findViewById(R.id.tvTech)
        val desc: TextView = v.findViewById(R.id.tvDesc)
        val link: TextView = v.findViewById(R.id.tvLink)
        val delete: Button = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_project, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = list[position]
        holder.title.text = p.title
        holder.tech.text = "Tech: ${p.techStack}"
        holder.desc.text = p.description
        holder.link.text = p.link
        holder.delete.setOnClickListener { onDelete(p) }
    }

    override fun getItemCount() = list.size
}