package com.example.portfolioapp

data class Project(
    var id: String = "",
    var title: String = "",
    var description: String = "",
    var techStack: String = "",
    var link: String = ""
)