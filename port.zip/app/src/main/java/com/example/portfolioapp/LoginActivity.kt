package com.example.portfolioapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            if (!isValid()) return@setOnClickListener
            auth.signInWithEmailAndPassword(text(etEmail), text(etPassword))
                .addOnSuccessListener { goHome() }
                .addOnFailureListener { toast(it.message) }
        }

        findViewById<Button>(R.id.btnRegister).setOnClickListener {
            if (!isValid()) return@setOnClickListener
            auth.createUserWithEmailAndPassword(text(etEmail), text(etPassword))
                .addOnSuccessListener { goHome() }
                .addOnFailureListener { toast(it.message) }
        }
    }

    private fun isValid(): Boolean {
        if (text(etEmail).isEmpty() || text(etPassword).length < 6) {
            toast("Enter email and a password of at least 6 characters")
            return false
        }
        return true
    }

    private fun text(e: EditText) = e.text.toString().trim()

    private fun toast(msg: String?) =
        Toast.makeText(this, msg ?: "Something went wrong", Toast.LENGTH_LONG).show()

    private fun goHome() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}